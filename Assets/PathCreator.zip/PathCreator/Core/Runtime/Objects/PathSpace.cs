﻿namespace PathCreation {
	public enum PathSpace {xyz, xy, xz};
}
